Insurance management tool designed for an Insurance company that had specifc needs. 

This is the first project I work on and when I started it I had not studied React.js or Vue.js and so I did not divide font-end and back-end.

Its mostly EJS with node and express plus Java script.

I eventually will implement Vue.js probably and separate front and back-end.
